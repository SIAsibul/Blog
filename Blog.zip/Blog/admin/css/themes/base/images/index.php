<html>
<?php 
	ob_start();
	header("Location: index.php");
?>
  <title>Forbidden!</title>
  <body>
    <h1>Access Denied !!</h1>
  </body>
</html>