<?php
define("DB_HOST", "localhost");
define("DB_USER", "root");
define("DB_PASS", "");
define("DB_NAME", "blog");
define("TITLE", "Home");
define("KEYWORDS", "Blog, CMS Blog");
define("DESCRIPTION", "It is a website about anything");
?>

